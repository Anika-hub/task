print('4th program')
print(float('123.456'))
print((float('123.456')) * 10)

print(int(123.456 * 10) % 10)

print(int((float('123.456')) * 10) % 10)



